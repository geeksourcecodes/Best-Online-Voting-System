<?php 
 ob_start();
session_start();
include("db_connect.php"); 

//Get the ipconfig details using system commond
system('ipconfig /all');
 
// Capture the output into a variable
$mycom=ob_get_contents();
// Clean (erase) the output buffer
ob_clean();
 
$findme = "Physical";
//Search the "Physical" | Find the position of Physical text
$pmac = strpos($mycom, $findme);
 
// Get Physical Address
$mac=substr($mycom,($pmac+36),17);
//Display Mac Address
//echo $mac;

$sqlu ="SELECT * FROM Results WHERE MAC='$mac'";
                    $retrieved = mysqli_query($db,$sqlu); 
					$totalvotes = mysqli_num_rows($retrieved);					                                      
                
				 
//Below is  the upload proposal button is clicked 
	if(isset($_POST['btnvote'])) 
     {
     	               
            if(!isset( $_COOKIE['Voter'])){
            	                    	
										
				if($_POST['district']!=''){											 	
   		     $district = mysqli_real_escape_string($db,$_POST['district']);			
	         $mcp=mysqli_real_escape_string($db,$_POST['mcp']);
			  $udf = mysqli_real_escape_string($db,$_POST['udf']);			
	  	     $pp=mysqli_real_escape_string($db,$_POST['pp']);
		     $dpp=mysqli_real_escape_string($db,$_POST['dpp']);
		   					
				         
                  if($mcp!='')
                                 { $vote="MCP";}
				 elseif($udf!='')
				                   { $vote="UDF";}
				 elseif($pp!='')
				                    { $vote="PP";}
				 elseif($dpp!='')
				                    { $vote="DPP";}
				 else {
                              $user="elections";
            	    setcookie("Voter",$user,time()+(3600*24*365));					  
  	                $_SESSION['sweetalertError2']="No district";
	                header("Location:index.php");
					      
						      exit;		      		
					       }
				 
						  			 
			              $date = date("d/m/y");	
               $query = "INSERT INTO Results (District,Party,Date,MAC) ".
               "VALUES ('$district', '$vote','$date','$mac')";
                $db->query($query) or die('Error, query failed');
					             $user="elections";
				 	setcookie("Voter",$user,time()+(3600*24*365));
					
					$_SESSION['sweetalertOK']="YoK";
	                    header("Location:index.php");						
				 }
            else{
            	                   $user="elections";
            	    setcookie("Voter",$user,time()+(3600*24*365));
					  
  	                $_SESSION['sweetalertError1']="No district";
	                header("Location:index.php");		      		
	
                 }

                 }
            else{
  	                $_SESSION['sweetalertError']="Yo";
	                header("Location:index.php");		      		
	
                 }
  }
 ?>             
                         