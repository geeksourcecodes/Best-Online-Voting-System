<?php 
 ob_start();
 session_start();
 include("db_connect.php");
 //Get the ipconfig details using system commond
system('ipconfig /all');
 
// Capture the output into a variable
$mycom=ob_get_contents();
// Clean (erase) the output buffer
ob_clean();
 
$findme = "Physical";
//Search the "Physical" | Find the position of Physical text
$pmac = strpos($mycom, $findme);
 
// Get Physical Address
$mac=substr($mycom,($pmac+36),17);

$sqlu ="SELECT * FROM Results WHERE MAC='$mac'";
                   $retrieved = mysqli_query($db,$sqlu); 
				$Macadress = mysqli_num_rows($retrieved);					                                      


?>

<!DOCTYPE html>
<html dir="ltr" lang="en-US">
	<head>
		<link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

    <meta charset="utf-8">
    <title>Home</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
    <meta property="og:title" content="MALAWI-MOCK ELECTION" />
    <meta property="og:url" content="http://www.malawimockelection.co.nf" />
    <meta property="og:description" content="This is a non-partisan event that mimic real elections please participate">
    <meta property="og:image" content="web3.png"> 
      
   
    <!--[if lt IE 9]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="style.css" media="screen">
    <!--[if lte IE 7]><link rel="stylesheet" href="style.ie7.css" media="screen" /><![endif]-->
    <link rel="stylesheet" href="style.responsive.css" media="all">
 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="script/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="script/sweetalert.css">
  
  
  
  
  <script src="script.js"></script>
  <script src="script.responsive.js"></script>
  
<style>.art-content .art-postcontent-0 .layout-item-0 { padding-right: 0px;padding-left: 0px;  }
.ie7 .art-post .art-layout-cell {border:none !important; padding:0 !important; }
.ie6 .art-post .art-layout-cell {border:none !important; padding:0 !important; }

</style>

             
</script>

<?php if(isset($_COOKIE['Voter'])) {?>
<script type="text/javascript"> 

$(document).ready(function(){ 
                           var myValue = "Load";
                                        swal({
                                         title: "Your back!",
                                         text: "Since you arleady voted,do you want to see how these parties are perfoming? Click results",
                                         type: "warning",
                                         showCancelButton: true,
                                        cancelButtonColor: "red",
                                        confirmButtonColor: "green",
                                        confirmButtonText: "Yes,Results!",
                                         cancelButtonText: "No, cancel!",
                                        closeOnConfirm: true,
                                        closeOnCancel:true,
                                          buttonsStyling: false
                                        },
                     function(isConfirm){
                                      if (isConfirm) {                                      	
                                                         window.location ="poll.php";
                                                     } 
                                           else {
	                                           // swal("Cancelled", "Your Proposal file is safe :)", "error");
                                             }
                                         });
                                         
                                                    });
       
                    </script>
   <?php }?>        


<?php if(isset($_SESSION['sweetalertOK'])) {?>
<script type="text/javascript"> 

$(document).ready(function(){ 
                           var myValue = "Load";
                                        swal({
                                         title: "You have voted successfully",
                                         text: "Click Results if you want to see how this election is going",
                                         type: "success",
                                         showCancelButton: true,
                                        cancelButtonColor: "red",
                                        confirmButtonColor: "green",
                                        confirmButtonText: "Yes,Results!",
                                         cancelButtonText: "No, cancel!",
                                        closeOnConfirm: true,
                                        closeOnCancel: true,
                                          buttonsStyling: false
                                        },
                     function(isConfirm){
                                      if (isConfirm) {                                      	
                                                         window.location ="poll.php";
                                                     } 
                                           else {
	                                           // swal("Cancelled", "Your Proposal file is safe :)", "error");
                                             }
                                         });
                                         
                                                    });
       
                    </script>
   <?php  session_destroy(); }?>        

 <?php if(isset($_SESSION['sweetalertError'])) {?>
<script type="text/javascript"> 
            $(document).ready(function(){    	
    				              sweetAlert("NO Way...", "You have arleady voted you cant vote again!", "error");     				              
                               });
                </script>
   <?php  session_destroy(); }?>  
   
   <?php if(isset($_SESSION['sweetalertError1'])) {?>
<script type="text/javascript"> 
 $(document).ready(function(){    	
    				              sweetAlert("Voting Mistake...", "You did not select the district your are voting for try again!", "error");     				              
                               });       
                    </script>
   <?php  
   
        session_destroy();
        setcookie("Voter","",time()-(3600*24*365));
		
    }?>        
   <?php if(isset($_SESSION['sweetalertError2'])) {?>
<script type="text/javascript"> 
 $(document).ready(function(){    	
    				              sweetAlert("Voting Mistake...", "You did not select a party your are voting for try again!", "error");     				              
                               });       
                    </script>
   <?php  
   
        session_destroy();
        setcookie("Voter","",time()-(3600*24*365));
		
    }?>        
   
   <?php if(!isset($_COOKIE['Voter'])&&$Macadress==0){?>
<script type="text/javascript"> 
           $(document).ready(function(){ 
                           var myValue = "Load";
                                        swal({
                                         title: "Terms & Conditions?",
                                         text: "Clicking Proceed you agree to our terms and conditions that your a Malawi ctizen of 18 years of age or above 18 and you would love to participate in this mock election",
                                        //type: "warning",
                                         showCancelButton: true,
                                        cancelButtonColor: "red",
                                        confirmButtonColor: "green",
                                        confirmButtonText: "Yes,Proceed!",
                                         cancelButtonText: "No, cancel!",
                                        closeOnConfirm: true,
                                        closeOnCancel: false,
                                          buttonsStyling: false
                                        },
                     function(isConfirm){
                                      if (isConfirm) {                                      	
                                             // function(){ location.reload(); }                                                  
                                           } 
                                           else {
	                                            swal("Too bad", "Thanks for being honest :)", "error");
                                             }
                                         });
                                         
                                                    });
         
       </script>
       
 <?php   }elseif(!isset($_COOKIE['Voter'])&&$Macadress!=0){  ?>
 	
	<script type="text/javascript"> 
            $(document).ready(function(){    	
    				              sweetAlert("NO Way...", "You have arleady voted you cant vote again!", "error");     				              
                               });
             </script>-->
	
 	
 <?php } ?>
 	
	

 
 </head>
<body>
<div id="art-main">
<header class="art-header" style="background-color: #FCFCFC;">

    <div class="art-shapes">
        <div class="art-object789181989"></div>

            </div>
<h1 class="art-headline">
    <a href="/" style="color: #FCFCFC;">I LOVE MALAWI</a>
</h1>
<h2 class="art-slogan">2018 Mock election for malawians by malawians</h2>

<marquee  scrollamount="4" class="art-marquee">This election started on 5 March 2018 will end on 5 April 2018</marquee>                
                    
</header>
<div class="art-sheet clearfix">
            <div class="art-layout-wrapper">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-content"><article class="art-post art-article">
                                
                                                
                <div class="art-postcontent art-postcontent-0 clearfix">
                	<div class="art-content-layout">
    <div class="art-content-layout-row">
    	        	
    <form method="post" action="vote.php" enctype='multipart/form-data'>        		

    <div class="art-layout-cell layout-item-0" style="width: 50%" >
        <span style="font-weight: bold; font-size: 14px; font-family: 'Courier New';">
        	SELECT DISTRICT :<select style='width:220px;height:37px;border:1px solid;' name="district"  id='district' > 
            				        <option value="" disabled selected>DISTRICT TO CAST YOUR VOTE</option>
            				                          
            				                            <option>Balaka</option>
            				                           <option>Blantyre</option>
            				                           <option>Chinkhwawa</option>
            				                           <option>Chiradzulu</option>
            				                           <option>Chitipa</option>
            				                           <option>Dedza</option>
            				                            <option>Dowa</option>
            				                            <option>Kasungu</option>
            				                            <option>Karonga</option>
            				                            <option>Lilongwe</option>
            				                            <option>Likoma</option>
							            				<option>Machinga</option>
							            				<option>Mangochi</option>
							            				<option>Mchinji</option>
							            				<option>Mulanje</option>
							            				<option>Mwanza</option>
							            				<option>Mzimba</option>
							            				<option>Mzuzu</option>
							            				<option>Neno</option>
							            				<option>Nkhatabay</option>
							            				<option>Nkhotakota</option>							            									            				
							            				<option>Ntchewu</option>
							            				<option>Ntchisi</option>
							       	                     <option>Nsanje</option>
							       	                     <option>Rumphi</option>     				
							            				<option>Salima</option>
							            	             <option>Thyolo</option>			
							            				<option>Phalombe</option>
							            				<option>Zomba</option>        				          				
            				           </select>
        </span>&nbsp;   
        
        
        	<p style="text-align: left;">
        	<span style="font-weight: bold; font-family: 'Courier New'; font-size: 20px;">
        		VOTE FOR PRESIDENT</span>
        	</p>
        	
        	  
      <table class="art-article" style="width: 100%; ">
      <tbody><tr>
      	<td style="width: 25%; "><img width="145" height="91" alt="" class="art-lightbox" src="images/imageedit_1_9959701143.png" radius="100%">
      <br><br><br>&nbsp;<label class="art-checkbox">
       <input type="checkbox" name="mcp"><span style="font-size: 16px; font-family: 'Times New Roman'; font-weight: bold;">MCP</span></label>
       </td>
       <td style="width: 25%; "><img width="145" height="91" alt="" class="art-lightbox" src="images/indexf.jpg" ><br><label class="art-checkbox"><br><br>&nbsp;
     <input type="checkbox" name="udf"><span style="font-family: 'Times New Roman'; font-weight: bold; font-size: 16px;">UDF</span></label><br>
     </td>
       <td style="width: 25%; "><img width="144" height="94" alt="" class="art-lightbox" src="images/indexx.jpg" >
       <br><br><br><label class="art-checkbox"><input type="checkbox" name="pp"><span style="font-family: 'Times New Roman'; font-size: 16px; font-weight: bold;">PP</span></label><br>
       </td>
       <td style="width: 25%; "><img width="128" height="131" alt="" class="art-lightbox" src="images/IMG_7309.png" ><br><label class="art-checkbox">
        <input type="checkbox" name="dpp"><span style="font-weight: bold; font-family: 'Times New Roman'; font-size: 16px;">DPP</span></label><br>
        </td></tr>
        </tbody>
        </table>
       <p style="text-align: left;"><span style="font-size: 14px; font-family: 'Courier New'; ">
       	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span>
     <span style="font-size: 14px; font-family: 'Courier New'; ">&nbsp;</span>
     
             <center><input type="submit" class="art-button" value="Cast Your Vote" id="btnvote" name="btnvote"></center> &nbsp;

   <span style="font-size: 14px; font-family: 'Courier New'; ">&nbsp;</span>
   <span style="color: rgb(255, 255, 255); "><span style="font-family: 'Courier New'; font-size: 14px;"></span></span>
   </p>
    </div>
    </form>  
    </div>
</div>

</div>


</article></div>
                    </div>
                </div>
            </div><footer class="art-footer">
<div style="position:relative;padding-left:10px;padding-right:10px"><p>© 2018, ilovemalawi2nyasaland@gmail.com . All Rights Reserved.</p></div>
</footer>

    </div>
    <p class="art-page-footer">
        <span id="art-footnote-links">
        </span>
    </p>
</div>


</body></html>